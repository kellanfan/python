from distutils.core import setup
setup(name='test',version='1.0',description='a test python packge', author='Kellan Fan', py_modules=['bao.Gcc', 'bao.Pots'])
