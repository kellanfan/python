#!/usr/bin/python
# -*- coding: UTF-8 -*-
 
def Gcc():
   print "I'm Gcc Phone"
